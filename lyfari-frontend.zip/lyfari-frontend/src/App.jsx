export default function App() {
  return <h1>Lyfari Frontend</h1>;
}