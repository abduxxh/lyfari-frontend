export default {
  root: "./src",
};